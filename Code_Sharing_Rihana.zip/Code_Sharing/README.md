\# README – Story County Census Mapping Toolbox



Author: Rihana Parvin Nipa

Date Created: 11/30/2025

Course: CRP 4560/5560 – GIS Programming \& Automation

Institution: Iowa State University – Department of Community \& Regional Planning





1\. PURPOSE OF THE CODE



This project provides a fully automated Python toolbox used to process and visualize U.S. Census data for Story County, Iowa. 

The toolbox allows any user to:



\- Select Census CSV and GeoJSON files

\- Convert the GeoJSON into a feature class

\- Join the CSV attribute table to the spatial tracts

\- Clean text values and convert them into a numeric DOUBLE field

\- Apply graduated color symbology automatically

\- Generate a matplotlib bar chart using the same mapped attribute

\- Save the graph as a PNG file



The entire workflow is designed to run on any computer with no hard-coded file paths.





2\. DATA ACCESSED



All data used in this project was downloaded from the U.S. Census Bureau Data Portal using the Advanced Search tool.



FILES USED:



1\. Census Tracts GeoJSON (Story County, IA)

&nbsp;  - Downloaded via “More Tools → GeoJSON”

&nbsp;  - Contains spatial boundaries for each census tract



2\. ACS Table S1903 — Median Income in the Past 12 Months 

&nbsp;  (in 2023 Inflation-Adjusted Dollars)

&nbsp;  - Downloaded using “More Tools → Table”

&nbsp;  - Represents tract-level median income estimates from the American Community Survey

&nbsp;  - Cleaned in Microsoft Excel using “Text to Columns”

&nbsp;  - Fields used:

&nbsp;      - Geography (join key)

&nbsp;      - Median Income in the Past 12 Months (main attribute)





3\. HOW TO RUN THE CODE PACKAGE



Step 1 — Open the Project

1\. Open StoryCensusProject.aprx in ArcGIS Pro

2\. In the Catalog pane, expand CensusTool.pyt

3\. Double-click the tool: “Story County Census Map \& Graph”



Step 2 — Fill In the Parameters

\- Census CSV file: select Median\_income.csv

\- Census tracts JSON file: select P504577759-2025-11-2009564883-MapLayer.json

\- Output workspace: select StoryCensusProject.gdb

\- CSV join field name: Geography

\- Feature class join field name: NAME

\- Attribute to map/graph: Median Income in the Past 12 Months

\- Color ramp choice: choose any (e.g., Blues)

\- Output PNG for graph: choose a filename such as MedianIncome\_Graph.png



Step 3 — Run the Tool

The tool will:

\- Convert the JSON into a feature class (StoryTracts\_fc)

\- Import the CSV as a table

\- Join the datasets

\- Create a numeric field (MedianIncomeNum)

\- Apply graduated color symbology

\- Generate and save a bar chart

\- Add the final layer to the map



A message indicating “Tool finished successfully” confirms completion.





**4. PROJECT FOLDER CONTENTS**



StoryCensusProject/

│

├── StoryCensusProject.aprx

├── CensusTool.pyt

├── Median\_income.csv

├── P504577759-2025-11-2009564883-MapLayer.json

├── StoryCensusProject.gdb/

├── MedianIncome\_Graph.png

└── README.md





5\. NOTES FOR REVIEWERS



This project is fully portable and designed to run on any machine.

To review the code:



1\. Download the full project folder

2\. Open the .aprx file in ArcGIS Pro

3\. Run the toolbox using the included data

4\. No modifications to file paths are needed



The tool will automatically create:

\- A fully symbolized map based on the numeric field

\- A saved matplotlib graph







